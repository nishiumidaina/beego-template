package clauses

const (
	ExprSep = "__"
	ExprDot = "."
)
